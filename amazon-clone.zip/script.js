const products = [
  { name: "Casque Bluetooth", price: 29.99, image: "https://via.placeholder.com/200x150?text=Casque" },
  { name: "Montre Connectée", price: 49.99, image: "https://via.placeholder.com/200x150?text=Montre" },
  { name: "Clavier Mécanique", price: 59.99, image: "https://via.placeholder.com/200x150?text=Clavier" },
  { name: "Souris Gaming", price: 19.99, image: "https://via.placeholder.com/200x150?text=Souris" }
];

const productList = document.getElementById("product-list");
const cartCount = document.getElementById("cart-count");
let count = 0;

products.forEach(p => {
  const div = document.createElement("div");
  div.className = "product";
  div.innerHTML = `
    <img src="${p.image}" alt="${p.name}" />
    <h3>${p.name}</h3>
    <p>${p.price.toFixed(2)} €</p>
    <button>Ajouter au panier</button>
  `;
  div.querySelector("button").addEventListener("click", () => {
    count++;
    cartCount.textContent = count;
  });
  productList.appendChild(div);
});
